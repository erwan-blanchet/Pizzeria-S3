<?php
  // Connexion à la base de données
  define("HOSTNAME", "localhost");
  define("DATABASE", "saes3-eblanc13");
  define("LOGIN", "saes3-eblanc13");
  define("PASSWORD", "YzlOrDbbTO8Qh1tO");
?>

package Modeles;
/**
 * Classe permettant la gestion des produits.
 * @author Estelle BOISSERIE
 * @author Erwan BLANCHET
 */
public class Produit {
	//------------------------------
	// ATTRIBUTS
	//------------------------------
	private int idProduit;
	private String nomProduit;
	private String typeProduit;


	//------------------------------
	// CONSTRUCTEUR
	//------------------------------
	/**
	 * Constructeur permettant de créer un objet produit.
	 * @param id L'identifiant du produit.
	 * @param nom Le nom du produit.
	 * @param type Le type de produit.
	 */
	public Produit(int id, String nom, String type) {
		this.idProduit = id;
		this.nomProduit = nom;
		this.typeProduit = type;
	}


	//------------------------------
	// ACCESSEURS
	//------------------------------
	public int getIdProduit() {
		return this.idProduit;
	}
	public void setIdProduit(int idProduit) {
		this.idProduit = idProduit;
	}
	public String getNomProduit() {
		return this.nomProduit;
	}
	public void setNomProduit(String nomProduit) {
		this.nomProduit = nomProduit;
	}
	public String getTypeProduit() {
		return this.typeProduit;
	}
	public void setTypeProduit(String typeProduit) {
		this.typeProduit = typeProduit;
	}



}
package Modeles;
import java.util.*;

/**
 * Cette classe permet de gérer les pizzaiolos.
 * @author Estelle BOISSERIE
 * @author Erwan BLANCHET
 */
public class Pizzaiolo {
	//------------------------------
	// ATTRIBUTS
	//------------------------------
	ArrayList<Commande> sesCommandes;
	private int idPizzaiolo;
	private String nomPizzaiolo;
	private String prenomPizzaiolo;
	private String adresseMailPizzaiolo;
	private String numeroTelephonePizzaiolo;
	private String motDePassePizzaiolo;
	private String disponibilitePizzaiolo;
	private int salairePizzaiolo;


	//------------------------------
	// CONSTRUCTEURS
	//------------------------------
	/**
	 * Constructeur permettant de créer un objet pizzaiolo avec toutes les informations.
	 * @param id L'identifiant du pizzaiolo.
	 * @param nom Le nom du pizzaiolo.
	 * @param prenom Le prénom du pizzaiolo.
	 * @param mail L'adresse mail du pizzaiolo.
	 * @param telephone Le numéro de téléphone du pizzaiolo.
	 * @param mdp Le mot de passe du pizzaiolo.
	 * @param disponibilite La disponibilité du pizzaiolo.
	 * @param salaire Le salaire du pizzaiolo.
	 */
	public Pizzaiolo(int id, String nom, String prenom, String mail, String telephone, String mdp, String disponibilite, int salaire) {
		this.idPizzaiolo = id;
		this.nomPizzaiolo = nom;
		this.prenomPizzaiolo = prenom;
		this.adresseMailPizzaiolo = mail;
		this.numeroTelephonePizzaiolo = telephone;
		this.motDePassePizzaiolo = mdp;
		this.disponibilitePizzaiolo = disponibilite; 
		this.salairePizzaiolo = salaire;
		this.sesCommandes = new ArrayList<Commande>();
	}

	/**
	 * Constructeur permettant de créer un objet pizzaiolo sans son prénom.
	 * @param id L'identifiant du pizzaiolo.
	 * @param nom Le nom du pizzaiolo.
	 * @param mail L'adresse mail de pizzaiolo.
	 * @param telephone Le numéro de téléphone du pizzaiolo.
	 * @param mdp Le mot de passe du pizzaiolo.
	 * @param disponibilite La disponibilité du pizzaiolo.
	 * @param salaire Le salaire du pizzaiolo.
	 */
	public Pizzaiolo(int id, String nom, String mail, String telephone, String mdp, String disponibilite, int salaire) {
		this.idPizzaiolo = id;
		this.nomPizzaiolo = nom;
		this.adresseMailPizzaiolo = mail;
		this.numeroTelephonePizzaiolo = telephone;
		this.motDePassePizzaiolo = mdp;
		this.disponibilitePizzaiolo = disponibilite; 
		this.salairePizzaiolo = salaire;
		this.sesCommandes = new ArrayList<Commande>();
	}



	//------------------------------
	// ACCESSEURS
	//------------------------------
	public int getIdPizzaiolo() {
		return this.idPizzaiolo;
	}
	public void setIdPizzaiolo(int idPizzaiolo) {
		this.idPizzaiolo = idPizzaiolo;
	}
	public String getNomPizzaiolo() {
		return this.nomPizzaiolo;
	}
	public void setNomPizzaiolo(String nomPizzaiolo) {
		this.nomPizzaiolo = nomPizzaiolo;
	}
	public String getPrenomPizzaiolo() {
		return this.prenomPizzaiolo;
	}
	public void setPrenomPizzaiolo(String prenomPizzaiolo) {
		this.prenomPizzaiolo = prenomPizzaiolo;
	}
	public String getAdresseMailPizzaiolo() {
		return this.adresseMailPizzaiolo;
	}
	public void setAdresseMailPizzaiolo(String adresseMailPizzaiolo) {
		this.adresseMailPizzaiolo = adresseMailPizzaiolo;
	}
	public String getNumeroTelephonePizzaiolo() {
		return this.numeroTelephonePizzaiolo;
	}
	public void setNumeroTelephonePizzaiolo(String numeroTelephonePizzaiolo) {
		this.numeroTelephonePizzaiolo = numeroTelephonePizzaiolo;
	}
	public String getMotDePassePizzaiolo() {
		return this.motDePassePizzaiolo;
	}
	public void setMotDePassePizzaiolo(String motDePassePizzaiolo) {
		this.motDePassePizzaiolo = motDePassePizzaiolo;
	}
	public String getDisponibilitePizzaiolo() {
		return this.disponibilitePizzaiolo;
	}
	public void setDisponibilitePizzaiolo(String disponibilitePizzaiolo) {
		this.disponibilitePizzaiolo = disponibilitePizzaiolo;
	}
	public int getSalairePizzaiolo() {
		return this.salairePizzaiolo;
	}
	public void setSalairePizzaiolo(int salairePizzaiolo) {
		this.salairePizzaiolo = salairePizzaiolo;
	}
	public void ajouterCommande(Commande commande) {
		this.sesCommandes.add(commande);
	}
	public void supprimerCommande(Commande commande) {
		this.sesCommandes.remove(commande);
	}
}
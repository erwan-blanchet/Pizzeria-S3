package Modeles;
import java.util.*;

/**
 * Classe permettant la gestion des pizzas.
 * @author Estelle BOISSERIE
 * @author Erwan BLANCHET
 */
public class Pizza {
	//------------------------------
	// ATTRIBUTS
	//------------------------------
	// une pizza possède des ingredients
	ArrayList<Ingredient> sesIngredients;
	private int idPizza;
	private String nomPizza;



	//------------------------------
	// CONSTRUCTEUR
	//------------------------------
	/**
	 * Constructeur permettant de créer un objet pizza.
	 * @param id L'identifiant de la pizza.
	 * @param nom Le nom de la pizza.
	 * @param listeIngredient , la liste des ingredient d'une seule pizza
	 */
	public Pizza(int id, String nom, ArrayList<Ingredient> listeIngredient) {
		this.idPizza = id;
		this.nomPizza = nom;
		this.sesIngredients = listeIngredient;
	}



	public ArrayList<Ingredient> getSesIngredients() {
		return sesIngredients;
	}



	public void setSesIngredients(ArrayList<Ingredient> sesIngredients) {
		this.sesIngredients = sesIngredients;
	}



	//------------------------------
	// ACCESSEURS
	//------------------------------
	public int getIdPizza() {
		return this.idPizza;
	}
	public void setIdPizza(int idPizza) {
		this.idPizza = idPizza;
	}
	public String getNomPizza() {
		return this.nomPizza;
	}
	public void setNomPizza(String nomPizza) {
		this.nomPizza = nomPizza;
	}
	public void ajouterIngredient(Ingredient ingredient) {
		this.sesIngredients.add(ingredient);
	}
	public void supprimerIngredient(Ingredient ingredient) {
		this.sesIngredients.remove(ingredient);
	}
}
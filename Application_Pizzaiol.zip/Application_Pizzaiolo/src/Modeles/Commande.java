package Modeles;

import java.sql.*;
import java.util.ArrayList;

import Main.ConnexionBDD;

/**
 * Cette classe permet de gérer les commandes.
 * @author  Estelle BOISSERIE
 * @author Erwan BLANCHET
 */
public class Commande {
	//------------------------------
	// ATTRIBUTS
	//------------------------------
	private Pizzaiolo sonPreparateur;
	private int numCommande;
	private Date dateCommande;
	private String statusCommande;
	private int delaisLivraison;
	private int totalCommande;
	// une commande possede une liste de pizza
	protected ArrayList<Pizza> listePizzas;
	// une commande possede une liste de produits
	protected ArrayList<Produit> listeProduits;

	

	//------------------------------
	// CONSTRUCTEUR
	//------------------------------
	/**
	 * Constructeur permettant de créer un objet commande.
	 * @param numero Le numéro de commande
	 * @param date La date de commande.
	 * @param status Le status de la commande.
	 * @param delais Le délais de la commande.
	 * @param listePizzas La liste des pizzas.
	 * @param listeProduits La liste des produits (boissons ou desserts).
	 */
	
	public Commande(int numero, String status, int prixCommande, int delaisLivraison,  ArrayList<Pizza> listePizzas, ArrayList<Produit> listeProduits) {
		this.numCommande = numero;
		this.statusCommande = status;
		this.totalCommande = prixCommande;
		this.delaisLivraison = delaisLivraison;
		this.listePizzas = listePizzas;
		this.listeProduits = listeProduits;
	}
	
	


	//------------------------------
	// ACCESSEURS
	//------------------------------
	public int getNumCommande() {
		return this.numCommande;
	}
	public void setNumCommande(int numCommande) {
		this.numCommande = numCommande;
	}
	public Date getDateCommande() {
		return this.dateCommande;
	}
	public void setDateCommande(Date dateCommande) {
		this.dateCommande = dateCommande;
	}
	public String getStatusCommande() {
		return this.statusCommande;
	}
	public void setStatusCommande(String statusCommande) {
		this.statusCommande = statusCommande;
	}
	public int getDelaisLivraison() {
		return this.delaisLivraison;
	}
	public void setDelaisLivraison(int delaisLivraison) {
		this.delaisLivraison = delaisLivraison;
	}
	public Pizzaiolo getSonPreparateur() {
		return sonPreparateur;
	}
	public void setSonPreparateur(Pizzaiolo sonPreparateur) {
		this.sonPreparateur = sonPreparateur;
	}
	public int getTotalCommande() {
		return totalCommande;
	}

	public void setTotalCommande(int totalCommande) {
		this.totalCommande = totalCommande;
	}

	public ArrayList<Pizza> getListePizzas() {
		return listePizzas;
	}

	public void setListePizzas(ArrayList<Pizza> listePizzas) {
		this.listePizzas = listePizzas;
	}

	public ArrayList<Produit> getListeProduits() {
		return listeProduits;
	}

	public void setListeProduits(ArrayList<Produit> listeProduits) {
		this.listeProduits = listeProduits;
	}
}
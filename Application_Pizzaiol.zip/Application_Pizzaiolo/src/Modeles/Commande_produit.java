package Modeles;

import java.util.ArrayList;

/**
 * Cette classe permet de gérer le lien entre les commandes et les produits. Les commande_produit sont un type de commande.
 * @author Estelle BOISSERIE
 * @author Erwan BLANCHET
 */
public class Commande_produit extends Commande {
	
	public Commande_produit(int numero, String status, int prixCommande, int delaisLivraison,
			ArrayList<Pizza> listePizzas, ArrayList<Produit> listeProduits) {
		super(numero, status, prixCommande, delaisLivraison, listePizzas, listeProduits);
		// TODO Auto-generated constructor stub
	}
	//------------------------------
	// ATTRIBUTS
	//------------------------------
	private Produit sonProduit;
	private int quantiteProduit;
	private Commande saCommande;



	//------------------------------
	// CONSTRUCTEUR
	//------------------------------
	/**
	 * Constructeur permettant de créer un objet faisant le lien entre un produit command� et une commande.
	 * @param commande La commande.
	 * @param produit Le produit commandé.
	 * @param quantite La quantité de produit.
	 */
	/*public Commande_produit(Commande commande, Produit produit, int quantite) {
		super(commande.getNumCommande(), commande.getDateCommande(), commande.getStatusCommande(), commande.getDelaisLivraison(), commande.getSonPreparateur());
		this.setSonProduit(produit);
		this.quantiteProduit = quantite;
		this.setSaCommande(commande);
	}*/



	//------------------------------
	// ACCESSEURS
	//------------------------------
	public int getQuantiteProduit() {
		return this.quantiteProduit;
	}
	public void setQuantiteProduit(int quantiteProduit) {
		this.quantiteProduit = quantiteProduit;
	}
	public Produit getSonProduit() {
		return sonProduit;
	}

	public void setSonProduit(Produit sonProduit) {
		this.sonProduit = sonProduit;
	}
	public Commande getSaCommande() {
		return saCommande;
	}
	public void setSaCommande(Commande saCommande) {
		this.saCommande = saCommande;
	}
}
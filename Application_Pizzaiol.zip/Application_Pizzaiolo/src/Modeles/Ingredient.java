package Modeles;
/**
 * Classe permettant la gestion des ingrédients.
 * @author Estelle BOISSERIE
 * @author Erwan BLANCHET
 */
public class Ingredient {
	//------------------------------
	// ATTRIBUTS
	//------------------------------
	private int idIngredient;
	private String nomIngredient;
	private int quantiteDeIngredient;



	//------------------------------
	// CONSTRUCTEUR
	//------------------------------
	/**
	 * Constructeur permettant de créer un objet ingrédient.
	 * @param id L'identifiant de l'ingrédient.
	 * @param nom Le nom de l'ingrédient.
	 * @param quantite La quantite d'ingrédient.
	 */
	public Ingredient(int id, String nom, int quantite) {
		this.idIngredient = id;
		this.nomIngredient = nom;
		this.quantiteDeIngredient = quantite;
	}



	public int getQuantiteDeIngredient() {
		return quantiteDeIngredient;
	}



	public void setQuantiteDeIngredient(int quantiteDeIngredient) {
		this.quantiteDeIngredient = quantiteDeIngredient;
	}



	//------------------------------
	// ACCESSEURS
	//------------------------------
	public int getIdIngredient() {
		return this.idIngredient;
	}
	public void setIdIngredient(int idIngredient) {
		this.idIngredient = idIngredient;
	}
	public String getNomIngredient() {
		return this.nomIngredient;
	}
	public void setNomIngredient(String nomIngredient) {
		this.nomIngredient = nomIngredient;
	}
}
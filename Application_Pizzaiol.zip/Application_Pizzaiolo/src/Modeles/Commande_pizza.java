package Modeles;

import java.util.ArrayList;

/**
 * Cette classe gère les commandes et pizzas commandes. Commande_pizza est un type de commande.
 * @author Estelle BOISSERIE
 * @author Erwan BLANCHET
 */
public class Commande_pizza extends Commande {
	
	
	public Commande_pizza(int numero, String status, int prixCommande, int delaisLivraison,
			ArrayList<Pizza> listePizzas, ArrayList<Produit> listeProduits) {
		super(numero, status, prixCommande, delaisLivraison, listePizzas, listeProduits);
		// TODO Auto-generated constructor stub
	}
	//------------------------------
	// ATTRIBUTS
	//------------------------------
	private Pizza saPizza;
	private Commande saCommande;
	private int quantitePizza;
	private String commentairePizza;
	private String statusPizza;



	//------------------------------
	// CONSTRUCTEURS
	//------------------------------
	/**
	 * Constructeur permettant de créer un objet faisant le lien entre une commande et une pizza command�es.
	 * @param commande La commande.
	 * @param pizza La pizza commandée.
	 * @param quantite La quantité de pizza.
	 * @param commentaire Le commentaire écrit par le client.
	 * @param status Le status de la commande.
	 */
	/*public Commande_pizza(Commande commande, Pizza pizza, int quantite, String commentaire, String status) {
		super(commande.getNumCommande(), commande.getDateCommande(), commande.getStatusCommande(), commande.getDelaisLivraison(), commande.getSonPreparateur());
		this.saPizza = pizza;
		this.quantitePizza = quantite;
		this.commentairePizza = commentaire;
		this.statusPizza = status;
		this.saCommande = commande;
	}*/

	/**
	 * Constructeur permettant de créer un objet faisant le lien entre une commande et sa pizza command� sans commentaire.
	 * @param commande La commande.
	 * @param pizza La pizza commandée.
	 * @param quantite La quantité de pizza.
	 * @param status Le status de la pizza.
	 */



	//------------------------------
	// ACCESSEURS
	//------------------------------
	public int getQuantitePizza() {
		return this.quantitePizza;
	}
	public void setQuantitePizza(int quantitePizza) {
		this.quantitePizza = quantitePizza;
	}
	public String getCommentairePizza() {
		return this.commentairePizza;
	}
	public void setCommentairePizza(String commentairePizza) {
		this.commentairePizza = commentairePizza;
	}
	public String getStatusPizza() {
		return this.statusPizza;
	}
	public void setStatusPizza(String statusPizza) {
		this.statusPizza = statusPizza;
	}
	public Pizza getSaPizza() {
		return saPizza;
	}
	public void setSaPizza(Pizza saPizza) {
		this.saPizza = saPizza;
	}
	public Commande getSaCommande() {
		return saCommande;
	}
	public void setSaCommande(Commande saCommande) {
		this.saCommande = saCommande;
	}
}
/**
 * @author BLANCHET Erwan TP3B1
 *
 */

package Main;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.*;

import com.mysql.cj.xdevapi.Statement;

public class ConnexionBDD {


	// Méthode pour établir la connexion à la base de données
	public static Connection obtenirConnexion() {
		Connection connexion = null;
		try {
			// Charger le driver JDBC
			Class.forName("com.mysql.cj.jdbc.Driver");
			// Les informations de connexion à la base de données
			String url = "jdbc:mysql://192.70.36.54/saes3-eblanc13?user=saes3-eblanc13&password=YzlOrDbbTO8Qh1tO&zeroDateTimeBehavior=convertToNull";
			System.out.println("Connection réussie");
			// Établir la connexion
			connexion = DriverManager.getConnection(url);
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println("impossible de se connecter");;
		}
		return connexion;
	}

	// Méthode pour fermer la connexion à la base de données

	public static void closeConnection(Connection co){
		try {
			co.close();
			System.out.println("Connexion fermée!");
		}
		catch (SQLException e) {
			System.out.println("Impossible de fermer la connexion");
		}
	}


	public static ResultSet exec1Requete (String requete, Connection co, int type){
		ResultSet resultatRequete=null;
		try {
			// Déclarer une variable de Statement
			Statement st;
			if (type==0){
				// Créer un objet statement
				st=(Statement) co.createStatement();}
			else {
				// Créer un objet statement
				st=(Statement) co.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
						ResultSet.CONCUR_READ_ONLY);
			};
			// Envoyer la requête et récupérer le résultat
			resultatRequete= ((java.sql.Statement) st).executeQuery(requete);
		}
		catch (SQLException e){
			System.out.println("Problème lors de l'exécution de la requete : "+requete);
		};
		return resultatRequete;
	}
	

}
/**
 * @author BLANCHET Erwan TP3B1
 *
 */


package Main;
import java.util.*;
import javax.swing.*;

import Controller.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.SQLException;

import Vue.*;
import Modeles.*;

public class Main {

	public static void main(String[] args) throws SQLException{
		System.out.println("Connexion en cours...");
		//Connection connexion = ConnexionBDD.obtenirConnexion();
		// création de la fenetre avec son nom
		JFrame fenetre = new JFrame("Application");
		// on recupere la taille de l'écran
		Dimension tailleEcran = Toolkit.getDefaultToolkit().getScreenSize();
		// on lui assigne la taille
		fenetre.setSize(tailleEcran.width, tailleEcran.height);
		// permet de fermer la fenêtre avec la croix
		fenetre.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);


		// création des différentes vues
		VueConnexion vueConnexion = new VueConnexion();
		VuePizzaiolo vuePizzaiolo = new VuePizzaiolo(vueConnexion);
		VueCreationCompte vueCreaCompte = new VueCreationCompte();
		
		ControllerConnexion controllerConnexion = new ControllerConnexion(vueConnexion, vuePizzaiolo, vueCreaCompte);
		ControllerCreationCompte controllerCreationCompte = new ControllerCreationCompte(vueConnexion, vueCreaCompte);
		ControllerPizzaiolo controllerPizzaiolo = new ControllerPizzaiolo(vuePizzaiolo);
		
		

		

		fenetre.add(vueConnexion);
		// Ajouter la vue à la fenêtre
		// Adapter la taille de la fenêtre
		fenetre.pack();
		// Afficher la fenetre
		fenetre.setVisible(true);


	}
}

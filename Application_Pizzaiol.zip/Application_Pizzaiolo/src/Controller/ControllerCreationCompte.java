/**
 * @author BLANCHET Erwan TP3B1
 *
 */

package Controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.*;

import Main.ConnexionBDD;
import Vue.*;
import Controller.*;

public class ControllerCreationCompte {

	private VueConnexion vueConnexion;
	private VueCreationCompte vueCreaCompte;
	
	ControllerConnexion controllerConnexion;
	
	// lorsque j'insère un nouveau pizzaiolo il lui faut un salaire qu'il ne rentre pas lui meme
	private final static int valeurSmic = 1766;
	
	public ControllerCreationCompte(VueConnexion vueConnexion, VueCreationCompte vueCreaCompte) {
		this.vueConnexion = vueConnexion;
		this.vueCreaCompte = vueCreaCompte;
		
		
		this.vueCreaCompte.btnRetourClick(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if(e.getSource() == vueCreaCompte.getBtnRetour()) {
					System.out.println("Retour à l'interface de connexion");
					JFrame fenetre = new JFrame();
					fenetre.add(vueConnexion);
					fenetre.pack();
					fenetre.setVisible(true);
					vueCreaCompte.fermerFenetre();
				}
				
			}
		});
		
		
		// lorsque l'utilisateur clique sur le bouton "crer compte"
		// des vérifications à la chaine se déclenche pour vérifier la conformité
		// si tout est bon on insert le compte
		this.vueCreaCompte.btnCrerCompteClick(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if(e.getSource() == vueCreaCompte.getBtnCreerCompte()) {
					// on attribue rien à prenom, car il est potentiellement null et donc on ne veut pas insérer du vide dans la base de donnée, si l'utilisateur n'a rien rentré on met prenom à null
					String prenom;
					// on récupere les éléments renseigné
					String nom = vueCreaCompte.getTxtNom().getText();
					String numTel = vueCreaCompte.getTxtNumeroTelephone().getText();
					String adresseMail = vueCreaCompte.getTxtAdresse().getText();
					String mdp = vueCreaCompte.getTxtMdp().getText();
					String confirmeMdp = vueCreaCompte.getTxtConfirmeMdp().getText();
					String mdpAutorisation = vueCreaCompte.getTxtMdpAutorisation().getText();
					
					// on va récupérer les données entrées par l'utilisateur
					// on insere null plutot que du vide
					if (vueCreaCompte.getTxtPrenom().getText().equals("")) {
						prenom = null;
					}
					else {
						prenom = vueCreaCompte.getTxtPrenom().getText();
					}
					
					// le mot de passe qui doit etre saisie, ce mot de passe est confidentiel, il permet d'éviter à n'importe qui de créer un compte
					String mdpASaisir = vueCreaCompte.getMdpautorisation();
					
					// on créer la connection
					Connection connection;
                    connection = ConnexionBDD.obtenirConnexion();
					
					// on va vérifier quelques modalités
					// -> le prenom peut etre null
					// si le mot de passe et le mot de passe confirmé sont les memes
					
					// je créer plusieurs if au lieu d'un seul avec plein de &&, car cela me permet de renvoyer à l'utilisateur ce qui est faut au lieu de simplement lui dire que c'est pas valide. Cela permet d'être plus précis sur le retour d'erreur
					if (mdp.equals(confirmeMdp)) {
						// pas la peine de vérifier prenom car il peut etre null, et confirmeMdp non plus car on verifie mdp ici et on verifie avant qu'ils sont les mêmes donc si mdp pas null alors confirmemdp non plus
						if (!nom.equals("") && !numTel.equals("") && !adresseMail.equals("") && !mdp.equals("")) {
							if(mdpAutorisation.equals(mdpASaisir)) {
								System.out.println("Création du compte en cours...");
								// maintenant que tout est bon on insert l'individu
								try {
									String query = "INSERT INTO INDIVIDU (Nom, Prenom, AdresseMail, NumeroTelephone, MotDePasse) VALUES (?,?,?,?,?);";
									PreparedStatement ps = connection.prepareStatement(query);
									//System.out.println(query);INSERT INTO INDIVIDU (Nom, Prenom, AdresseMail, NumeroTelephone, MotDePasse) VALUES ('Boisserie','estelle','boisserie.estelle@email.com','07.98.98.98.98','dd');
									ps.setString(1, nom);	
									ps.setString(2, prenom);
									ps.setString(3, adresseMail);
									ps.setString(4, numTel);
									ps.setString(5, mdp);
									// execute la requete
									int execute = ps.executeUpdate();
									// vérification données insérées
									if(execute > 0) {
										System.out.println("Données INDIVIDU insérées");
									}
									// nous avons insérer les données dans INDIVIDU mais on a pas encore spécifié que c'est un pizzaiolo
									// ajoutons des données dans pizzaiolo pour spécifier que cet individu est un pizzaiolo
									int idIndividuOnVientInserer = 0;
									Statement statement = connection.createStatement();
									String query2 = "SELECT INDIVIDU.idIndividu FROM INDIVIDU WHERE INDIVIDU.AdresseMail = '"+adresseMail+"';";
									ResultSet resultat = statement.executeQuery(query2);
									if (resultat.next()) {
										idIndividuOnVientInserer = resultat.getInt("idIndividu");
									}
									// maintenant qu'on a recuperer l'id on va pouvoir l'inserer
									String query3 = "INSERT INTO PIZZAIOLO (DisponibilitePizzaiolo, SalairePizzaiolo, IndividuPizzaiolo) VALUES (?,?,?);";
									PreparedStatement ps1 = connection.prepareStatement(query3);
									ps1.setString(1, "Disponible");
									ps1.setInt(2, valeurSmic);
									ps1.setInt(3, idIndividuOnVientInserer);
									int execute1 = ps1.executeUpdate();
									if(execute1 > 0) {
										System.out.println("Données PIZZAIOLO insérées");
									}
									
									
									// on revient sur l'écran de connexion
									JFrame fenetre = new JFrame();
									fenetre.add(vueConnexion);
									fenetre.pack();
									fenetre.setVisible(true);
									vueCreaCompte.fermerFenetre();
								} catch (SQLException ex){
									ex.printStackTrace();
								}finally {
			                        try {
			                            connection.close();
			                        } catch (SQLException ex) {
			                            ex.printStackTrace();
			                        }
			                    }
			                    try {
									connection.close();
									System.out.println("Connexion fermée...");
								} catch (SQLException e1) {
									// TODO Auto-generated catch block
									e1.printStackTrace();
								}
							}
							else {
								//System.out.println("L'utilisateur à saisie deux mot de passe différents");
								JOptionPane.showMessageDialog(null, "le mot de passe d'autorisation de création de compte n'est pas bon, veuillez contacter le gestionnaire !", "Avertissement", JOptionPane.WARNING_MESSAGE);
		                	}
						}
						// un des champs est vide
						else {
							//System.out.println("Il manque un champ à compléter");
	                		JOptionPane.showMessageDialog(null, "Veuillez saisir tout les champs !", "Avertissement", JOptionPane.WARNING_MESSAGE);
						}
					}
					else {
                		//System.out.println("le mot de passe d'autorisation de création de compte n'est pas bon, veuillez contacter le gestionnaire");
                		JOptionPane.showMessageDialog(null, "Les mots de passes ne concordent pas !", "Avertissement", JOptionPane.WARNING_MESSAGE);
					}
					// enfin on ferme la connection
					ConnexionBDD.closeConnection(connection);
				}
				
			}
		});
	}
}

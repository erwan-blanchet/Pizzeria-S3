/**
 * @author BLANCHET Erwan TP3B1
 *
 */

package Controller;

import javax.swing.JButton;

// cette classe va me permettre de créer des boutons reconnaissable indifférement des autres grace à un identifiant supplémentaire
// on extends JButton car cela reste un bouton
public class ControllerCommandeButton extends JButton {

	// on créer un noouvel attribut
	private int indexCommande;
	
	public ControllerCommandeButton(String text, int indexCommande) {
		super(text);
		this.indexCommande = indexCommande;
	}

	
	
	public int getIndexCommande() {
		return indexCommande;
	}

	public void setIndexCommande(int indexCommande) {
		this.indexCommande = indexCommande;
	}
	
	
}

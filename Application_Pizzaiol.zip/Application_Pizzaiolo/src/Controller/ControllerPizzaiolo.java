/**
 * @author BLANCHET Erwan TP3B1
 *
 */

package Controller;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;

import Main.ConnexionBDD;
import Vue.*;

public class ControllerPizzaiolo {

	VuePizzaiolo vuePizzaiolo;

	public ControllerPizzaiolo(VuePizzaiolo vuePizzaiolo) {
		this.vuePizzaiolo = vuePizzaiolo;

		
	}
}

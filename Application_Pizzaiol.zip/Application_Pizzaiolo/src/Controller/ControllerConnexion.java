/**
 * @author BLANCHET Erwan TP3B1
 *
 */

package Controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import Main.ConnexionBDD;
import Vue.*;
import Modeles.*;
public class ControllerConnexion {
	private VueConnexion vueConnexion;
	private VuePizzaiolo vuePizzaiolo;
	private VueCreationCompte vueCreationCompte;

	public ControllerConnexion(VueConnexion vueConnexion, VuePizzaiolo vuePizzaiolo, VueCreationCompte vueCreationCompte) {
		this.vueConnexion = vueConnexion;
		this.vuePizzaiolo = vuePizzaiolo;
		this.vueCreationCompte = vueCreationCompte;

		this.vueConnexion.btnConnecterClick(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				// string qui va contenir l'email dans la base de données afin de s'en servir plus tard
				String emailIndividuDansBd = "";
				// string qui va contenir le mot de passe dans la base de données afin de s'en servir plus tard
				String mdpIndividuDansBd = "";
				// int qui va contenir l'identifiant dans la base de données afin de s'en servir plus tard
				int idIndividuDansBd = 0;
				boolean estPizzaiolo = false;

				String email = vueConnexion.getTxtEmail().getText();
				if (e.getSource() == vueConnexion.getBtnConnecter()) {
					Connection connection;
					connection = ConnexionBDD.obtenirConnexion();
					System.out.println("bouton connecter clické");
					System.out.println(email);
					try {
						ResultSet resultatRequete = execRequete("SELECT INDIVIDU.AdresseMail, INDIVIDU.MotDePasse, INDIVIDU.idIndividu FROM INDIVIDU WHERE INDIVIDU.AdresseMail = '"+email+"';", connection, 0);
						while (resultatRequete.next()) {
							String emailIndividu = resultatRequete.getString("AdresseMail");
							String mdpIndividu = resultatRequete.getString("MotDePasse");
							int idIndividu = resultatRequete.getInt("idIndividu");
							// on attribue le resultat à une variable plus gobale
							emailIndividuDansBd = emailIndividu;
							// on attribue le resultat à une variable plus gobale
							mdpIndividuDansBd = mdpIndividu;
							// on attribue le resultat à une variable plus gobale
							idIndividuDansBd = idIndividu;
							System.out.println("Bienvenue : "+email);
						}
						// le seul moyen de récupérer correctement le resultat de ma requete avec COUNT était de passer avec un Statement
						Statement statement = connection.createStatement();
						String query = "SELECT COUNT(PIZZAIOLO.IndividuPizzaiolo) AS nombre FROM PIZZAIOLO WHERE PIZZAIOLO.IndividuPizzaiolo = "+idIndividuDansBd+";";
						ResultSet resultat = statement.executeQuery(query);
						if(resultat.next()) {
							int nombre = resultat.getInt("nombre");
							// si le resultat du count est 1 cela signifi qu'on à trouvé son identifiant une fois dans la table PIZZAIOLO donc que l'individu es un pizzaiolo
							if(nombre == 1) {
								estPizzaiolo = true;
								if ((vueConnexion.getTxtEmail().getText().equals(emailIndividuDansBd)) && (vueConnexion.getTxtMotDePasse().getText().equals(mdpIndividuDansBd)) && (estPizzaiolo == true)) {
									System.out.println("Vous êtes connecté à votre compte");
									JFrame fenetre = new JFrame();
									VuePizzaiolo vuePizzaiolo = new VuePizzaiolo(vueConnexion);
									fenetre.add(vuePizzaiolo);
									fenetre.pack();
									fenetre.setVisible(true);
									vueConnexion.fermerFenetre();
								} else {
									JOptionPane.showMessageDialog(null, "Nous ne vous avons pas trouvés dans la base de données !", "Avertissement", JOptionPane.WARNING_MESSAGE);
									System.out.println("identifiants pas bons");
								}
							}
							// pas besoin de else car par defaut estPizaiolo est faux
							else {
								JOptionPane.showMessageDialog(null, "Vous n'êtes pas un pizzaiolo accès refusé !", "Avertissement", JOptionPane.WARNING_MESSAGE);
							}
						}
						
						
						// ce bout de code permet lors de la connexion d'un pizzaiolo de passer son statut en "En cuisine" pour indiquer qu'il est connecté et qu'il travaille
						String query1 = "UPDATE PIZZAIOLO SET DisponibilitePizzaiolo = ? WHERE PIZZAIOLO.individuPizzaiolo = "+idIndividuDansBd;
						System.out.println("UPDATE PIZZAIOLO SET DisponibilitePizzaiolo = ? WHERE PIZZAIOLO.individuPizzaiolo = "+idIndividuDansBd);
						PreparedStatement preparepst1 = connection.prepareStatement(query1);
						preparepst1.setString(1, "En cuisine");
						preparepst1.executeUpdate();
						
					} catch (SQLException ex) {
						ex.printStackTrace();
					}
					
					// on ferme la connexion à la base de donnée
					ConnexionBDD.closeConnection(connection);
				}
			}
		});

		// on traite l'action du bouton retour en fermant l'appli
		this.vueConnexion.btnRetourClick(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if (e.getSource() == vueConnexion.getBtnRetour()) {
					System.out.println("bouton retour clické");
					vueConnexion.fermerFenetre();
				}
			}
		});

		// on traite l'action en ouvrant la vue de création d'un compte
		this.vueConnexion.btnPasDeCompte(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if (e.getSource() == vueConnexion.getBtnPasDeCompte()) {
					System.out.println("creation du compte en cours");
					JFrame fenetre = new JFrame();
					// on ajoute la vue voulue
					fenetre.add(vueCreationCompte);
					fenetre.pack();
					fenetre.setVisible(true);
					vueConnexion.fermerFenetre();
				}
			}
		});
	}

	
	// exemple type d'une execution de requete
	public static ResultSet execRequete(String requete, Connection co, int type) {
		ResultSet resultatRequete = null;
		try {
			Statement st;
			if (type == 0) {
				st = co.createStatement();
			} else {
				st = co.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
			}
			resultatRequete = st.executeQuery(requete);
		} catch (SQLException e) {
			System.out.println("Problème lors de l'exécution de la requete : " + requete);
		}
		return resultatRequete;
	}
}

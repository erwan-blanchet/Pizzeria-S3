/**
 * @author BLANCHET Erwan TP3B1
 *
 */

package Vue;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class VueCreationCompte extends JPanel {

	//****************************************************************//
	//*************************** ATTRIBUTS***************************//
	//****************************************************************//
	
	// le mot de pass qui va servir à la création d'un compte pour pas que tout le monde puisse créer de compte
	private final static String mdpAutorisation = "bonsoir";
	
    // declaration des différentes zones de texte que l'utilisateur devra saisir
	private JTextField txtPrenom;
    private JTextField txtNom;
    private JTextField txtNumeroTelephone;
    private JTextField txtAdresseMail;
    private JTextField txtMdp;
    private JTextField txtConfirmeMdp;
    private JTextField txtMdpAutorisation;
    private JButton btnCreerCompte;
    private JButton btnRetour;

    // declaration d'une vue
    VueConnexion vueConnexion;

    
    
	//****************************************************************//
	//************************ CONSTRUCTEUR***************************//
	//****************************************************************//
    public VueCreationCompte() {
        setLayout(new BorderLayout());

        // Panel principal avec GridBagLayout
        JPanel panelPrincipal = new JPanel(new GridBagLayout());
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.insets = new Insets(6, 5, 5, 5); // Marge entre les composants

        // panel pour la création du formulaire de création de compte
        JPanel panelFormulaire = new JPanel(new GridLayout(7, 2, 10, 10));
        panelFormulaire.add(new JLabel("Prénom : (facultatif)"));
        txtPrenom = new JTextField();
        panelFormulaire.add(txtPrenom);
        panelFormulaire.add(new JLabel("Nom : (obligatoire)"));
        txtNom = new JTextField();
        panelFormulaire.add(txtNom);
        panelFormulaire.add(new JLabel("Numéro de Téléphone : format (0X.XX.XX.XX.XX)"));
        txtNumeroTelephone = new JTextField();
        panelFormulaire.add(txtNumeroTelephone);
        panelFormulaire.add(new JLabel("Adresse mail : (obligatoire)"));
        txtAdresseMail = new JTextField();
        panelFormulaire.add(txtAdresseMail);
        panelFormulaire.add(new JLabel("Mot de passe : (obligatoire)"));
        txtMdp = new JTextField();
        panelFormulaire.add(txtMdp);
        panelFormulaire.add(new JLabel("Confirmer mot de passe : (obligatoire)"));
        txtConfirmeMdp = new JTextField();
        panelFormulaire.add(txtConfirmeMdp);
        panelFormulaire.add(new JLabel("Mot de passe d'autorisation : (obligatoire)"));
        txtMdpAutorisation = new JTextField();
        panelFormulaire.add(txtMdpAutorisation);

        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.gridwidth = 2;
        panelPrincipal.add(panelFormulaire, constraints);

        // Bouton "Créer Compte"
        btnCreerCompte = new JButton("Créer Compte");
        constraints.gridy = 1;
        constraints.gridwidth = 1;
        panelPrincipal.add(btnCreerCompte, constraints);

        // Bouton "Retour"
        btnRetour = new JButton("Retour");
        constraints.gridx = 1;
        constraints.gridy = 1;
        panelPrincipal.add(btnRetour, constraints);

        // Ajout du panel principal à la vue
        add(panelPrincipal, BorderLayout.CENTER);
    }

    
    
	//****************************************************************//
	//*************************** METHODES ***************************//
	//****************************************************************//
    public void btnCrerCompteClick(ActionListener ecouteur) {
        btnCreerCompte.addActionListener(ecouteur);
    }

    public void btnRetourClick(ActionListener ecouteur) {
        btnRetour.addActionListener(ecouteur);
    }

    public void fermerFenetre() {
        Window parentWindow = SwingUtilities.windowForComponent(VueCreationCompte.this);
        if (parentWindow != null) {
            parentWindow.dispose(); // Ferme la fenêtre parente
        }
    }
    
    
    
    
    
	//****************************************************************//
	//******************* ACCESSEUR / GETTER *************************//
	//****************************************************************//
    public JTextField getTxtPrenom() {
		return txtPrenom;
	}

	public void setTxtPrenom(JTextField txtPrenom) {
		this.txtPrenom = txtPrenom;
	}

	public JTextField getTxtNom() {
		return txtNom;
	}

	public void setTxtNom(JTextField txtNom) {
		this.txtNom = txtNom;
	}

	public JTextField getTxtNumeroTelephone() {
		return txtNumeroTelephone;
	}

	public void setTxtNumeroTelephone(JTextField txtNumeroTelephone) {
		this.txtNumeroTelephone = txtNumeroTelephone;
	}

	public JTextField getTxtAdresse() {
		return txtAdresseMail;
	}

	public void setTxtAdresse(JTextField txtAdresse) {
		this.txtAdresseMail = txtAdresse;
	}

	public JTextField getTxtMdp() {
		return txtMdp;
	}


	public void setTxtMdp(JTextField txtMdp) {
		this.txtMdp = txtMdp;
	}


	public JTextField getTxtConfirmeMdp() {
		return txtConfirmeMdp;
	}


	public void setTxtConfirmeMdp(JTextField txtConfirmeMdp) {
		this.txtConfirmeMdp = txtConfirmeMdp;
	}


	public JButton getBtnCreerCompte() {
		return btnCreerCompte;
	}

	public void setBtnCreerCompte(JButton btnCreerCompte) {
		this.btnCreerCompte = btnCreerCompte;
	}

	public JButton getBtnRetour() {
		return btnRetour;
	}

	public void setBtnRetour(JButton btnRetour) {
		this.btnRetour = btnRetour;
	}

	public VueConnexion getVueConnexion() {
		return vueConnexion;
	}

	public static String getMdpautorisation() {
		return mdpAutorisation;
	}

	public void setVueConnexion(VueConnexion vueConnexion) {
		this.vueConnexion = vueConnexion;
	}public JTextField getTxtAdresseMail() {
		return txtAdresseMail;
	}

	public void setTxtAdresseMail(JTextField txtAdresseMail) {
		this.txtAdresseMail = txtAdresseMail;
	}

	public JTextField getTxtMdpAutorisation() {
		return txtMdpAutorisation;
	}

	public void setTxtMdpAutorisation(JTextField txtMdpAutorisation) {
		this.txtMdpAutorisation = txtMdpAutorisation;
	}

	
}

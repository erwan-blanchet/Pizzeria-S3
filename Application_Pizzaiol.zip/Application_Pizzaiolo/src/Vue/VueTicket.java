/**
 * @author BLANCHET Erwan TP3B1
 *
 */

package Vue;

import java.awt.Color;
import java.awt.Dimension;
import java.sql.*;

import javax.swing.*;

import Main.ConnexionBDD;
import Modeles.*;
public class VueTicket extends JPanel{

	//****************************************************************//
	//*************************** ATTRIBUTS***************************//
	//****************************************************************//
	
	// déclaration des labels
	private JLabel lblInfosDestinataire;
	private JLabel lblInfosCommande;
	private JLabel lblRemerciement;
	
	// déclaration des panels
	private JPanel pnlBandeau;
	private JPanel pnlInfos;
	private JPanel pnlfooter;
	private JPanel pnlGeneral;
	
	
	
	
	
	//****************************************************************//
	//************************ CONSTRUCTEUR***************************//
	//****************************************************************//
	public VueTicket(Commande commande) {
		// on crer une connection
		Connection connection = ConnexionBDD.obtenirConnexion();
		
		// on affecte des bordures au panels pour une meilleure clarté
		pnlBandeau = new JPanel();
		pnlBandeau.setBorder(BorderFactory.createLineBorder(Color.black, 2, true));
		pnlInfos = new JPanel();
		pnlInfos.setBorder(BorderFactory.createLineBorder(Color.black, 2, true));
		pnlfooter = new JPanel();
		pnlfooter.setBorder(BorderFactory.createLineBorder(Color.black, 2, true));
		pnlGeneral = new JPanel();
		pnlGeneral.setLayout(new BoxLayout(pnlGeneral, BoxLayout.Y_AXIS));
		
	
		// on déclare des variables qui seront complétées au fur et a mesure 
		// on les declare ici car nous les réutiliserons
		String nom = "";
		String prenom = "";
		int numeroAdresse = 0;
		String suffixeAdresse = "";
		String nomRue = "";
		String complementAdresse = "";
		String nomVille = "";
		String adresse = "";
		try {
			// création du statement
			Statement statementNom = connection.createStatement();
			// création de la requete
			String queryNom = "SELECT ADRESSE.numero,ADRESSE.suffixeAdresse, ADRESSE.NomRue, ADRESSE.ComplementAdresse, VILLE.NomVille, INDIVIDU.Nom, INDIVIDU.Prenom FROM INDIVIDU INNER JOIN CLIENT ON INDIVIDU.idIndividu = CLIENT.idClient INNER JOIN COMMANDE ON CLIENT.idClient = COMMANDE.numCommande INNER JOIN ADRESSE ON CLIENT.adresseClient = ADRESSE.idAdresse INNER JOIN VILLE ON ADRESSE.villeAdresse = VILLE.idVille WHERE COMMANDE.numCommande = "+commande.getNumCommande();
			ResultSet requeteNom = statementNom.executeQuery(queryNom);
			// execution de la requete avec recuperation des valeurs
			while(requeteNom.next()) {
				// on attribut les valeurs aux variables précédentes
				nom = requeteNom.getString("nom");
				prenom = requeteNom.getString("prenom");
				numeroAdresse = requeteNom.getInt("numero");
				suffixeAdresse = requeteNom.getString("suffixeAdresse");
				nomRue = requeteNom.getString("NomRue");
				complementAdresse = requeteNom.getString("ComplementAdresse");
				nomVille = requeteNom.getString("NomVille");
			}

			// il se peut qu'un des deux ou les deux soient nuls donc lors de l'affiche nous ne voulons pas afficher null ce qui fait que nous remettons sous forme vide pour un meilleur affichage
			if (suffixeAdresse == null) {
				suffixeAdresse = "";
			}
			if (complementAdresse == null) {
				complementAdresse = "";
			}
			// on créer l'adresse dans une seule variable
			adresse = numeroAdresse+" "+suffixeAdresse+" "+nomRue+" "+complementAdresse+" à "+nomVille;
		}catch(SQLException ex) {
			ex.printStackTrace();
		}
		
		// on affiche les infos du client pour le livreur
		lblInfosDestinataire = new JLabel("Commande numéro : "+commande.getNumCommande()+" à destination de : "+nom+", "+prenom+" à l'adresse : "+adresse);
		pnlBandeau.add(lblInfosDestinataire);
		
		
		// on affiche un petit recap de la commande sur le ticket
		StringBuilder pizzasEtProduits = new StringBuilder("<html></br>");
		for (Pizza pizza : commande.getListePizzas()) {
			pizzasEtProduits.append("Pizza - ").append(pizza.getNomPizza()).append("<br>");
			System.out.println();
		}
		for (Produit produit : commande.getListeProduits()) {
			if (produit.getTypeProduit().equals("Boisson")) {
				pizzasEtProduits.append("Boisson - ").append(produit.getNomProduit()).append("<br>");
			}
			else {
				pizzasEtProduits.append("Dessert - ").append(produit.getNomProduit()).append("<br>");
			}
		}
		pizzasEtProduits.append("</html>");
		lblInfosCommande = new JLabel(pizzasEtProduits.toString());
		pnlInfos.add(lblInfosCommande);
		
		
		// on y ajoute un petit label pour remercier le client
		lblRemerciement = new JLabel("Merci pour votre commande, noous éspérons vous revoir d'ici peu, bon appétit, toutes l'équipe Crousti'l Vintage");
		pnlfooter.add(lblRemerciement);
		
		
		// on ajoute les différents panels avec des espaces pour un meilleur graphisme
		pnlGeneral.add(pnlBandeau);
		pnlGeneral.add(this.creationEspace());
		pnlGeneral.add(pnlInfos);
		pnlGeneral.add(this.creationEspace());
		pnlGeneral.add(pnlfooter);
		
		// on ajoute le tout à la fenetre
		this.add(pnlGeneral);
		
	}
	
	
	
	/**
	 * @return un panel qui donne l'illusion d'un espace
	 */
	private JPanel creationEspace() {
		VuePizzaiolo vue = new VuePizzaiolo(null);
		JPanel pnlEspace = new JPanel();
		pnlEspace.setBackground(vue.couleurFondApp);
		pnlEspace.setPreferredSize(new Dimension(20,20));
		return pnlEspace;
	}
}

/**
 * @author BLANCHET Erwan TP3B1
 *
 */

package Vue;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import javax.swing.*;

import Main.ConnexionBDD;
import Modeles.Commande;
import Modeles.Ingredient;
import Modeles.Pizza;
import Modeles.Produit;

// cette vue permet l'affiche des ingredients mais surtout le détail d'une commande
// elle sert donc à imprimer le ticket ainsi valider et consulter une commande


public class VueCommandeDetail extends JPanel{
	
	//****************************************************************//
	//*************************** ATTRIBUTS***************************//
	//****************************************************************//
	
	// declaration des vues
	private VuePizzaiolo vuePizzaiolo;
	private VueConnexion vueConnexion;
	private VueTicket vueTicket;
	
	// declaration des boutons
	private JButton btnValiderCommande;
	private JButton btnRetour;
	private JButton btnTicket;
	
	// declaration des panels
	private JPanel pnlBandeau;
	private JPanel pnlInfos;
	private JPanel pnlBoutons;
	private JPanel pnlGeneral;
	
	// declaration des labels
	private JLabel lblNumCommande;
	private JLabel lblCommande;
	private JLabel lblListeIngredient;
		
	
	//****************************************************************//
	//************************* CONSTRUCTEUR *************************//
	//****************************************************************//
	public VueCommandeDetail(VuePizzaiolo vuePizzaiolo, Commande commande){
		// initialisation
		this.vuePizzaiolo = vuePizzaiolo;
		
		// creation de la connexion
		Connection connection = ConnexionBDD.obtenirConnexion();
		this.setBackground(vuePizzaiolo.couleurFondApp);
		
		// taille de la fenetre
		setSize(300,400);
		
		// affectatation du numero de commande dans le bandeau supérieur
		lblNumCommande = new JLabel("Commande numéro : "+commande.getNumCommande());
		
		// on construit à la suite un string qui va afficher en détails les commandes
		StringBuilder pizzasEtProduits = new StringBuilder("<html></br>");
		// affiche le nom de la pizza
		for (Pizza pizza : commande.getListePizzas()) {
			pizzasEtProduits.append("Pizza - ").append(pizza.getNomPizza()).append("<br>");
			System.out.println();
		}
		
		// en fonction de son type affiche son type puis son nom
		for (Produit produit : commande.getListeProduits()) {
			if (produit.getTypeProduit().equals("Boisson")) {
				pizzasEtProduits.append("Boisson - ").append(produit.getNomProduit()).append("<br>");
			}
			else {
				pizzasEtProduits.append("Dessert - ").append(produit.getNomProduit()).append("<br>");
			}
		}
		pizzasEtProduits.append("</html>");
		lblCommande = new JLabel(pizzasEtProduits.toString());
		
		
		// on va afficher les ingredient pour chaque pizza ainsi que leurs quantités
		StringBuilder lesIngredients = new StringBuilder("<html></br>");
		for (Pizza pizza : commande.getListePizzas()) {
			lesIngredients.append(pizza.getNomPizza()).append("<br>");
			for (Ingredient ingredient : pizza.getSesIngredients()) {
				lesIngredients.append(ingredient.getNomIngredient()).append(", ").append(ingredient.getQuantiteDeIngredient()).append("<br>");
			}
		}
		// on ferme la balise
		lesIngredients.append("</html>");
		lblListeIngredient = new JLabel(lesIngredients.toString());
		
		
		
		// on s'occupe du bouton retour pour revenir à toutes les commandes
		
		btnRetour = new JButton("Retour");
		btnRetour.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				JFrame fenetre = new JFrame();
				fenetre.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				VuePizzaiolo vuePizzaiolo = new VuePizzaiolo(new VueConnexion());
				fenetre.add(vuePizzaiolo);
				fenetre.pack();
				fenetre.setVisible(true);
				fermerFenetre();
			}
			
		});
			
		
		// on s'occupe de valider la commande et de l'enviyer au livreur car le pizzaiolo la coche comme validé et finit
		btnValiderCommande = new JButton("Valider la commande");
		btnValiderCommande.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				// ce bout de code concerne le changement dans la base de données concernant le statut de commande
				String query = "UPDATE COMMANDE SET StatutCommande = ? WHERE COMMANDE.NumCommande = "+commande.getNumCommande();
				PreparedStatement preparepst = null;
				try {
					preparepst = connection.prepareStatement(query);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				try {
					preparepst.setString(1, "Prête pour livraison");
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				// execute mise a jour des données
				int execution = 0;
				try {
					execution = preparepst.executeUpdate();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}


				// on va rafraichir la page, pour ca je ferme le vue et rouvre une nouvelle
				JFrame fenetre = new JFrame();
				VuePizzaiolo vuePizzaiolo = new VuePizzaiolo(vueConnexion);
				fenetre.add(vuePizzaiolo);
				fenetre.pack();
				fenetre.setVisible(true);
				fermerFenetre();

				// si > 0 cela signifie qu'une lige à bien été changé donc il y a bien eu mise à jour
				if (execution > 0) {
					System.out.println("Données lise à jour pour la commande"+commande.getNumCommande());
				}
				else {
					System.out.println("Mise a jour non effectuée");
				}
			}
			
		});
		
		
		// comme demandé le pizzaiolo peut imprimer un ticket, ce bouton s'en occupe en ouvrant une nouvelle fenetre avec la commande
		btnTicket = new JButton("Imprimer");
		btnTicket.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				JFrame fenetre = new JFrame();
				VueTicket vueTicket = new VueTicket(commande);
				fenetre.add(vueTicket);
				fenetre.pack();
				fenetre.setVisible(true);
			}
			
		});
		
		
		
		
		
		
		// ----------------------------------------------------------------- //
		// on gère la mise en forme avec les ajouts des différents espaces et des différents panels
		
		
		pnlGeneral = new JPanel();
		pnlGeneral.setLayout(new BoxLayout(pnlGeneral, BoxLayout.Y_AXIS));
		
		pnlBandeau = new JPanel();
		pnlBandeau.setPreferredSize(new Dimension(getWidth(), 50));
		pnlBandeau.setBorder(BorderFactory.createLineBorder(Color.black, 2, true));
		pnlBandeau.add(lblNumCommande);
		
		pnlInfos = new JPanel();
		pnlInfos.setLayout(new BoxLayout(pnlInfos, BoxLayout.X_AXIS));
		pnlInfos.add(lblCommande);
		pnlInfos.add(Box.createHorizontalStrut(10));
		JSeparator separateur = new JSeparator(SwingConstants.VERTICAL);
		separateur.setPreferredSize(new Dimension(2,20));
		pnlInfos.add(separateur);
		pnlInfos.add(Box.createHorizontalStrut(10));
		//pnlInfos.setBorder(BorderFactory.createLineBorder(Color.black, 2, true));
		pnlInfos.add(lblListeIngredient);
		
		pnlBoutons = new JPanel();
		pnlBoutons.setPreferredSize(new Dimension(getWidth(), 100));
		pnlBoutons.setBorder(BorderFactory.createLineBorder(Color.black, 2, true));
		pnlBoutons.add(btnRetour);
		pnlBoutons.add(btnValiderCommande);
		pnlBoutons.add(btnTicket);
			
		pnlGeneral.add(pnlBandeau);
		pnlGeneral.add(this.creationEspace());
		pnlGeneral.add(pnlInfos);
		pnlGeneral.add(this.creationEspace());
		pnlGeneral.add(pnlBoutons);
		
		add(pnlGeneral);
	}
	
	
	
	
	
	
	/**
	 * Cette méthode va créer un panel de couleur de fond de l'app qui donne l'illusions d'un espace pour un graphisme plus harmonieux
	 * @return un panel créeant un espace vide permettant la séparation des éléments
	 */
	private JPanel creationEspace() {
		JPanel pnlEspace = new JPanel();
		pnlEspace.setBackground(vuePizzaiolo.couleurFondApp);
		pnlEspace.setPreferredSize(new Dimension(20,20));
		return pnlEspace;
	}
	
	/**
	 * Cette méthode permet de fermer une fenetre afin d'avoir toujours une seule fenetre ouverte sauf en cas d'exception voulue
	 * ferme la fenetre
	 */
	public void fermerFenetre() {
		Window parentWindow = SwingUtilities.windowForComponent(VueCommandeDetail.this);
		if (parentWindow != null) {
			parentWindow.dispose(); // Ferme la fenêtre parente
		}
	}
	
	
	public VuePizzaiolo getVuePizzaiolo() {
		return vuePizzaiolo;
	}

	public void setVuePizzaiolo(VuePizzaiolo vuePizzaiolo) {
		this.vuePizzaiolo = vuePizzaiolo;
	}

	public JButton getBtnValiderCommande() {
		return btnValiderCommande;
	}

	public void setBtnValiderCommande(JButton btnValiderCommande) {
		this.btnValiderCommande = btnValiderCommande;
	}

	public JButton getBtnRetour() {
		return btnRetour;
	}

	public void setBtnRetour(JButton btnRetour) {
		this.btnRetour = btnRetour;
	}

	public JPanel getPnlBandeau() {
		return pnlBandeau;
	}

	public void setPnlBandeau(JPanel pnlBandeau) {
		this.pnlBandeau = pnlBandeau;
	}

	public JPanel getPnlInfos() {
		return pnlInfos;
	}

	public void setPnlInfos(JPanel pnlInfos) {
		this.pnlInfos = pnlInfos;
	}

	public JPanel getPnlBoutons() {
		return pnlBoutons;
	}

	public void setPnlBoutons(JPanel pnlBoutons) {
		this.pnlBoutons = pnlBoutons;
	}

	public JPanel getPnlGeneral() {
		return pnlGeneral;
	}

	public void setPnlGeneral(JPanel pnlGeneral) {
		this.pnlGeneral = pnlGeneral;
	}

	public JLabel getLblNumCommande() {
		return lblNumCommande;
	}

	public void setLblNumCommande(JLabel lblNumCommande) {
		this.lblNumCommande = lblNumCommande;
	}

	public JLabel getLblCommande() {
		return lblCommande;
	}

	public void setLblCommande(JLabel lblCommande) {
		this.lblCommande = lblCommande;
	}

	
	
}

/**
 * @author BLANCHET Erwan TP3B1
 *
 */

package Vue;

import java.awt.*;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import javax.swing.*;

import Main.ConnexionBDD;
import Modeles.*;
import Controller.*;

import javax.swing.*;

public class VuePizzaiolo extends JPanel{
	
	//**************************************************************************//
	//********************************* ATTRIBUTS ******************************//
	//**************************************************************************//
	
	// simple attribut qui permet de savoir si un bouton est coché dans la vue
	private boolean coche = false;
	
	
	//************** COULEUR ***************//
	// public car je vais me servir de cette couleur pour la vue en détails des commandes (VueCommandeDetail), c'est la couleur de fond de l'application
	public Color couleurFondApp = new Color(204, 204, 102);

	//************** LABEL ***************//
	// un label qui va contenir le numero de la commande pour identifier plus précisément les commandes
	private JLabel lblNumCommande;

	//************** BOUTON ***************//
	// bouton qui va deconnecter le pizzaiolo
	private JButton btnDeconnexion;
	// bouton qui rafraichit la page, le bouton valider le fait aussi, mais si il y a 0 commande au début, commeent rafraichir la page s'il n'y a pas de commande donc pas de bouton valider
	private JButton btnRafraichir;


	//************** APPEL DE VUE ***************//
	VueConnexion vueConnexion;
	VueCommandeDetail vueCommandeDetail;

	//************** ARRAYLIST POUR STOCKER LES COMMANDES ET LES TRIER POUR AVOIR A FAIRE QU'UN SEUL APPEL A LA BASE DE DONNEES ***************//
	// arrayList de toutes les commandes
	private ArrayList<Commande> commandes = new ArrayList<>();
	// arrayList des commandes en cours de preparation
	private ArrayList<Commande> commandeEnCoursLivraison = new ArrayList<>();
	// arrayList des commandes livree
	private ArrayList<Commande> commandeLivree = new ArrayList<>();
	// arrayList des commande validee
	private ArrayList<Commande> commandeValidee = new ArrayList<>();
	// arrayList des commandes en preparation par le pizzaiolo
	private ArrayList<Commande> commandeEnPreparation = new ArrayList<>();

	// arrayList des produits d'une commande
	private ArrayList<Produit> listeProduits = new ArrayList<>();
	// arrayList des Pizzaq d'une commande car il peut y en avoir plusieurs
	private ArrayList<Pizza> listePizzas = new ArrayList<>();
	// arrayList des ingredients d'une seule pizza
	private ArrayList<Ingredient> listeIngredient = new ArrayList<>();

	
	
	
	
	
	//*****************************************************************************//
	//********************************* CONSTRUCTEUR ******************************//
	//*****************************************************************************//
	
	public VuePizzaiolo(VueConnexion vueConnexion) {
		// initialisation
		this.vueConnexion = vueConnexion;

		// Définir la couleur de fond moutarde
		setBackground(couleurFondApp);
		setSize(400,400);

		
		
		//*****************************************************************************//
		//************************ BANDEAU SUPERIEUR DE LA VUE ************************//
		//*****************************************************************************//
		// creation du bandeau en haut de la vue
		JPanel pnlBandeau = new JPanel();
		// on lui affecte une couleur
		pnlBandeau.setBackground(couleurFondApp);
		// on lui affecte une taille
		pnlBandeau.setPreferredSize(new Dimension(this.getWidth(), 50));
		
		
		// ------------------------------------------------------------------ //

		// horloge du bandeau qui va afficher l'heure en temps réel
		JLabel lblHorloge = new JLabel();
		Timer timer = new Timer(1000, e ->{
			// convertion au format voulu
			SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
			lblHorloge.setText(sdf.format(new java.util.Date()));
		});
		// on démarre le timer
		timer.start();
		// puis on ajoute
		pnlBandeau.add(lblHorloge);
		
		
		// ------------------------------------------------------------------ //

		// ajout du message et des statistiques

		// on va recupérer le nom de la personne connectée
		// pour ca on sait que la personne connecté possede "en cuisine" dans son statut donc on a juste à aller chercher la personne qui possède ce statut et recupérer son nom
		// a savoir que lorsqu'un pizzaiolo se connecte on change son statut pour le mettre "en cuisine, et que lorsqu'il se deconnecte son statut devient "Disponible"

		// on déclare les prenom et nom en dehors car nous nous en reservirons plus tard
		String prenomIndividu = "";
		String nomIndividu = "";
		try {
			// on créer une instance de type Connection
			Connection connection;
			// on affecte tout nos paramètres pour que la connection soit établie
			connection = ConnexionBDD.obtenirConnexion();
			
			// -------------------- cette requete va nous permettre d'afficher le nom du pizzaiolo de connecté pour lui souhaiter la bienvenue
			// on créer un statement avec notre connection
			Statement statementPrenomPizzaiolo = connection.createStatement();
			// on créer la requete
			String queryPrenomPizzaiolo = "SELECT INDIVIDU.prenom, INDIVIDU.nom FROM INDIVIDU INNER JOIN PIZZAIOLO ON INDIVIDU.idIndividu = PIZZAIOLO.individuPizzaiolo WHERE PIZZAIOLO.disponibilitePizzaiolo = 'En cuisine';";
			// on finit par le resultset qui execute la requete
			ResultSet resultatAvoirNomPizzaiolo = statementPrenomPizzaiolo.executeQuery(queryPrenomPizzaiolo);
			// nous allons afficher le tout
			while(resultatAvoirNomPizzaiolo.next()) {
				// on recupere le prenom
				prenomIndividu = resultatAvoirNomPizzaiolo.getString("prenom");
				// on recupere le nom
				nomIndividu = resultatAvoirNomPizzaiolo.getString("nom");
			}
			
		}catch (SQLException ex) { // on relève éventuellement une exception en cas de problème
			ex.printStackTrace();
		}

		// on affiche le message de bienvenue avec les infos de notre pizzaiolo
		JLabel lblMessage = new JLabel("Bienvenue : "+prenomIndividu+", "+nomIndividu.toUpperCase());
		pnlBandeau.add(lblMessage);
		// on ajoute le tout

		// ------------------------------------------------------------------ //
		
		// ce bout de code est une case à cocher qui va permettre de demander vérification au pizzaiolo s'il est sur de valider une commande ou non
		JCheckBox box = new JCheckBox("Confirmation des commandes");
		box.addItemListener(new ItemListener() {
			@Override
			public void itemStateChanged(ItemEvent e) {
				// TODO Auto-generated method stub
				if(e.getStateChange() == ItemEvent.SELECTED && !coche) {
					System.out.println("activée");
					coche = true;
				}
				else if (e.getStateChange() == ItemEvent.DESELECTED && coche){
					System.out.println("desactivée");
					coche = false;
				}
			}
		});
		// on ajoute au bandeau
		pnlBandeau.add(box);
		// on ajooute le bandeau à la fenetre
		this.add(pnlBandeau, BorderLayout.NORTH);
		
		
		// ------------------------------------------------------------------ //
		
		
		
		
		
		
		//*****************************************************************************//
		//************************ CREATION DES COMMANDES DE LA VUE  ******************//
		//*****************************************************************************//
					
		// on le déclare plus haut car je vaus m'en resservir plus tard pour l'identification de quel bouton est cliqué car pour chaque commande il y a les memes
		int numeroCommande = 0;
		// on va chercher dans la base de données les différentes données
		try {
			// on crée une connection
			Connection connection;
			connection = ConnexionBDD.obtenirConnexion();
			// on s'occupe de la requete
			Statement statement = connection.createStatement();
			String query = "SELECT numCommande, statutCommande, totalCommande, delaisLivraison FROM COMMANDE;";
			ResultSet requete = statement.executeQuery(query);
			// on traite la requete
			while (requete.next()) {

				// création de la commande
				numeroCommande = requete.getInt("numCommande");
				String statutCommande = requete.getString("StatutCommande");
				int prixCommande = requete.getInt("totalCommande");
				int delaisLivraison = requete.getInt("delaisLivraison");

				// liste des pizza
				listePizzas = new ArrayList<>();
				Statement statementPizza = connection.createStatement();
				String queryPizza = "SELECT PIZZA.idPizza, PIZZA.NomPizza FROM commande_pizza INNER JOIN PIZZA ON commande_pizza.PizzaCommande = PIZZA.idPizza WHERE commande_pizza.commandeEffectue = "+numeroCommande;
				ResultSet requetePizza = statementPizza.executeQuery(queryPizza);
				while (requetePizza.next()) {
					int idPizza = requetePizza.getInt("idPizza");
					String nomPizza = requetePizza.getString("nomPizza");
					// on créer l'instance de la pizza
					// mais on fait les ingredient en premier car une pizza possede une liste d'ingredient
					Statement statementIngredient = connection.createStatement();
					String queryIngredient = "SELECT INGREDIENT.NomIngredient, INGREDIENT.idIngredient, compose_de.quantiteDeIngredient FROM INGREDIENT INNER JOIN compose_de ON INGREDIENT.idIngredient = compose_de.IngredientNecessaire INNER JOIN PIZZA ON compose_de.RecettePizza = PIZZA.idPizza WHERE PIZZA.idPizza = "+idPizza;
					ResultSet requeteIngredient = statementIngredient.executeQuery(queryIngredient);
					listeIngredient = new ArrayList<>();
					while(requeteIngredient.next()) {
						String nomIngredient = requeteIngredient.getString("nomIngredient");
						int idIngredient = requeteIngredient.getInt("idIngredient");
						int quantiteIngredient = requeteIngredient.getInt("quantiteDeIngredient");
						Ingredient ingredient = new Ingredient(idIngredient, nomIngredient, quantiteIngredient);
						listeIngredient.add(ingredient);
					}
					Pizza pizza = new Pizza(idPizza,nomPizza, listeIngredient);
					listePizzas.add(pizza);
				}

				// liste des produits
				listeProduits = new ArrayList<>();
				Statement statementProduit = connection.createStatement();
				String queryProduit = "SELECT PRODUIT.idProduit, PRODUIT.nomProduit, PRODUIT.TypeProduit FROM commande_produit INNER JOIN PRODUIT ON commande_produit.ProduitCommande = PRODUIT.idProduit WHERE commande_produit.CommandeFait = "+numeroCommande;
				ResultSet requeteProduit = statementProduit.executeQuery(queryProduit);
				while(requeteProduit.next()) {
					int idProduit = requeteProduit.getInt("idProduit");
					String nomProduit = requeteProduit.getString("nomProduit");
					String typeProduit = requeteProduit.getString("typeProduit");
					// on créer la nouvelle instance du produit
					Produit produit = new Produit(idProduit, nomProduit, typeProduit);
					// on ajoute au table de produits le produit
					listeProduits.add(produit);
				}

				// création de l'instance commande faisant référence au modele
				Commande commande = new Commande(numeroCommande,statutCommande,prixCommande, delaisLivraison, listePizzas, listeProduits);
				this.commandes.add(commande);


				// affectation des commandesn dans des tableau en fonction des status, permet de les trier
				
				// si la commande est en cours de livraison alors on l'affecte au bon tableau pareil pour les autres cas
				if (commande.getStatusCommande().equals("En cours de livraison")) {
					this.commandeEnCoursLivraison.add(commande);
				}
				else if(commande.getStatusCommande().equals("Livrée")) {
					this.commandeLivree.add(commande);
				}
				else if(commande.getStatusCommande().equals("En préparation")) {
					this.commandeEnPreparation.add(commande);
				}
				else if (commande.getStatusCommande().equals("Validée")) {
					this.commandeValidee.add(commande);
				}
			}


			// affichage à la vertical ou à l'horizontal cela permet de choisir ici en l'occurence vertical
			setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
			
			// je vais créer deux panels cote à cote, un avec les commandes pas encore prise en compte et l'autre avec les commandes prises par le pizzaiolo
			JPanel pnlPrincipal = new JPanel(new GridLayout(1,2));
			// panel des commandes non prise en compte
			JPanel pnlCommandeValidee = new JPanel(new GridLayout(commandeValidee.size(),1));
			// panel des commandes prise en compte
			JPanel pnlCommandeEnPreparation = new JPanel(new GridLayout(commandeEnPreparation.size(),1));
			
			// on booucle pour afficher chaque commande du tableau
			for (int i = 0; i < commandeValidee.size(); i++) {
				// on recupere son numero de commande
				int cetteNumeroCommande = commandeValidee.get(i).getNumCommande();
				// on créer un autre panel pour cette fois le contenu de la commande
				JPanel pizzaPanel = new JPanel(new BorderLayout());
				// on créer une bordure foncé pour bien différencié les parties
				pizzaPanel.setBorder(BorderFactory.createLineBorder(Color.BLACK)); 

				// on affiche les différentes informations
				lblNumCommande = new JLabel("commande numéro : " + cetteNumeroCommande);
				lblNumCommande.setFont(new Font("Arial", Font.BOLD, 16));
				lblNumCommande.setHorizontalAlignment(SwingConstants.CENTER);
				pizzaPanel.add(lblNumCommande, BorderLayout.NORTH);

				
				
				// Description de la pizza
				// sachant qu'une commande possede des pizzas qui possede elle meme des ingredient
				/// qu'une commande possede des produits
				
				// nous allons implémenter une chaine de caractere au fut et à mesure
				StringBuilder pizzasEtProduits = new StringBuilder("<html></br>");
				for (Pizza pizza : commandeValidee.get(i).getListePizzas()) {
					// pour chaque on affiche son type avec son nom
					pizzasEtProduits.append("Pizza - ").append(pizza.getNomPizza()).append("<br>");
					System.out.println();
				}
				for (Produit produit : commandeValidee.get(i).getListeProduits()) {
					if (produit.getTypeProduit().equals("Boisson")) {
						// pour chaque on affiche son type avec son nom
						pizzasEtProduits.append("Boisson - ").append(produit.getNomProduit()).append("<br>");
					}
					else {
						// si c'est pas une boisson alors c'est un dessert
						// pour chaque on affiche son type avec son nom
						pizzasEtProduits.append("Dessert - ").append(produit.getNomProduit()).append("<br>");
					}
				}
				// le parametre n'étant pas un string mais un stringBuuilder alors on le convertit vers le bon type
				JLabel lblDescriptionPizza = new JLabel(pizzasEtProduits.toString());
				lblDescriptionPizza.setHorizontalAlignment(SwingConstants.CENTER);
				pizzaPanel.add(lblDescriptionPizza, BorderLayout.EAST);

				
				
				
				
				
				
				// chronometre
				// requete pour aller chercher le dernier delais de livraison connu et enregistré dans la base de donnes
				// pour réaliser ce chronomètre je vais stocker sous forme de int le nombre de seconde de la commande par exemple si je veus stocker 3 min et 10 seconde c'est (3x60 + 10) = 190 qu'on stocke dans la bd
				int chrono = 0;
				Statement statementChrono = connection.createStatement();
				String queryChrono = "SELECT COMMANDE.DelaisLivraison FROM COMMANDE WHERE COMMANDE.numCommande = "+cetteNumeroCommande+";";
				ResultSet resultat = statementChrono.executeQuery(queryChrono);
				while(resultat.next()) {
					chrono = resultat.getInt("delaisLivraison");
				}
				JPanel pnlBottom = new JPanel(new BorderLayout());
				JLabel lblChrono = new JLabel(Integer.toString(chrono));
				pizzaPanel.add(lblChrono, BorderLayout.AFTER_LAST_LINE);
				
				
				
				
				
				
				
				
				// Panel pour les boutons
				JPanel buttonPanel = new JPanel(new GridLayout(1, 2, 10, 0)); // GridLayout pour aligner les boutons horizontalement
				buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); // Espacement autour du panel

				pnlBottom.add(buttonPanel, BorderLayout.CENTER);
				pnlBottom.add(lblChrono, BorderLayout.SOUTH);
				pizzaPanel.add(lblChrono, BorderLayout.WEST);				
				
				
				// bouton en preparation
				ControllerCommandeButton btnEnPreparation = new ControllerCommandeButton("Préparer la commande", cetteNumeroCommande);
				btnEnPreparation.setPreferredSize(new Dimension(200,20));
				btnEnPreparation.addActionListener(new ActionListener() {

					@Override
					public void actionPerformed(ActionEvent e) {
						// TODO Auto-generated method stub
						// on va aller changer le statut de la commande dans la base de donnée pour indiquer que le pizzaiolo s'en occupe
						try {
							String query = "UPDATE COMMANDE SET StatutCommande = ? WHERE COMMANDE.NumCommande = "+cetteNumeroCommande+";";
							PreparedStatement preparepst = connection.prepareStatement(query);
							preparepst.setString(1, "En préparation");
							// execution mise a jour
							preparepst.executeUpdate();
							// on rafraichis la page pour mettre a jours les commande sur la vue
							JFrame fenetre = new JFrame();
							VuePizzaiolo vuePizzaiolo = new VuePizzaiolo(vueConnexion);
							fenetre.add(vuePizzaiolo);
							fenetre.pack();
							fenetre.setVisible(true);
							fermerFenetre();
						} catch(SQLException ex) {
							ex.printStackTrace();
						}
					}
					});
				buttonPanel.add(btnEnPreparation);

				// Ajout du panel de boutons en bas de la vue
				pizzaPanel.add(buttonPanel, BorderLayout.SOUTH);

				// Ajout du panel de pizza au panel principal
				pnlCommandeValidee.add(pizzaPanel);

			}
		
			
			// ------------------------ le second panel ---------------------//
			// Ajouter le label à la fenêtre
			// Ajout de pizzas directement dans la boucle
			for (int i = 0; i < commandeEnPreparation.size(); i++) {
				int cetteNumeroCommande = commandeEnPreparation.get(i).getNumCommande();
				JPanel pizzaPanel = new JPanel(new BorderLayout());
				pizzaPanel.setBorder(BorderFactory.createLineBorder(Color.BLACK)); // Pour une bordure autour du carré

				// Nom de la pizza
				lblNumCommande = new JLabel("commande numéro : " + cetteNumeroCommande);
				lblNumCommande.setFont(new Font("Arial", Font.BOLD, 16));
				lblNumCommande.setHorizontalAlignment(SwingConstants.CENTER);
				pizzaPanel.add(lblNumCommande, BorderLayout.NORTH);

				// Description de la pizza
				//JLabel lblDescriptionPizza = new JLabel("Pizza : "+commandeEnPreparation.get(i).getListePizzas().get(0).getNomPizza());
				StringBuilder pizzasEtProduits = new StringBuilder("<html></br>");
				for (Pizza pizza : commandeEnPreparation.get(i).getListePizzas()) {
					//pizzas.append(pizza.getNomPizza()).append("\n");
					pizzasEtProduits.append("Pizza - ").append(pizza.getNomPizza()).append("<br>");
					System.out.println();
				}
				for (Produit produit : commandeEnPreparation.get(i).getListeProduits()) {
					if (produit.getTypeProduit().equals("Boisson")) {
						pizzasEtProduits.append("Boisson - ").append(produit.getNomProduit()).append("<br>");
					}
					else {
						pizzasEtProduits.append("Dessert - ").append(produit.getNomProduit()).append("<br>");
					}
				}
				// le parametre n'étant pas un string mais un stringBuuilder alors on le convertit vers le bon type
				JLabel lblDescriptionPizza = new JLabel(pizzasEtProduits.toString());
				lblDescriptionPizza.setHorizontalAlignment(SwingConstants.CENTER);
				pizzaPanel.add(lblDescriptionPizza, BorderLayout.EAST);

				
				
				
				
				// chronometre
				// requete pour aller chercher le dernier delais de livraison connu et enregistré dans la base de donnes
				// pour réaliser ce chronomètre je vais stocker sous forme de int le nombre de seconde de la commande par exemple si je veus stocker 3 min et 10 seconde c'est (3x60 + 10) = 190 qu'on stocke dans la bd
				int chrono = 0;
				Statement statementChrono = connection.createStatement();
				String queryChrono = "SELECT COMMANDE.DelaisLivraison FROM COMMANDE WHERE COMMANDE.numCommande = "+cetteNumeroCommande+";";
				ResultSet resultat = statementChrono.executeQuery(queryChrono);
				while(resultat.next()) {
					chrono = resultat.getInt("delaisLivraison");
				}
				JPanel pnlBottom = new JPanel(new BorderLayout());
				JLabel lblChrono = new JLabel(Integer.toString(chrono));
				pizzaPanel.add(lblChrono, BorderLayout.AFTER_LAST_LINE);
				
				
				
				
				
				
				// Panel pour les boutons
				JPanel buttonPanel = new JPanel(new GridLayout(1, 2, 10, 0)); // GridLayout pour aligner les boutons horizontalement
				buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); // Espacement autour du panel

				pnlBottom.add(buttonPanel, BorderLayout.CENTER);
				pnlBottom.add(lblChrono, BorderLayout.SOUTH);
				pizzaPanel.add(lblChrono, BorderLayout.WEST);				
				
				
				// bouton en preparation
				ControllerCommandeButton btnEnPreparation = new ControllerCommandeButton("Préparer la commande", cetteNumeroCommande);
				//Commande
				// Bouton "Détails"
				ControllerCommandeButton btnDetails = new ControllerCommandeButton("Détails", cetteNumeroCommande);
				Commande laCommande = commandeEnPreparation.get(i);
				btnDetails.setPreferredSize(new Dimension(200,20));
				btnDetails.addActionListener(new ActionListener() {

					@Override
					public void actionPerformed(ActionEvent e) {
						// TODO Auto-generated method stub
						System.out.println("bouton details cliqué");

						JFrame fenetre = new JFrame();
						fenetre.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
						VueCommandeDetail vueCommandeDetail = new VueCommandeDetail(new VuePizzaiolo(vueConnexion), laCommande);
						fenetre.add(vueCommandeDetail);
						fenetre.pack();
						fenetre.setVisible(true);
						fermerFenetre();
					}

				});
				buttonPanel.add(btnDetails);

				
				
				
				// ---------------------- creation des boutons pour chaque commande //
				// pour chaque bouton j'ai recréer une classe qui etend JButton, mais qui prend en plus un parametre d'un identifiant
				// cet identifiant est le numéro de la commmande car c'est le seul moyen d'avoir quelque chose d'unique pour chaque commande
				// lorsqu'un boouton est cliqué je recupère son identifiant pour effectuer les différents changement dû à ce bouton
				// Bouton "Valider"
				// voici la classe
				ControllerCommandeButton btnValider = new ControllerCommandeButton("Valider", commandeEnPreparation.get(i).getNumCommande());
				btnValider.addActionListener(new ActionListener() {

					@Override
					public void actionPerformed(ActionEvent e) {
						// TODO Auto-generated method stub
						System.out.println("bouton valider cliqué");
						try {

							// vérification de la case de demande de vérification pour la validation des commandes
							if (coche == false) {
								// ce bout de code concerne le changement dans la base de données concernant le statut de commande
								String query = "UPDATE COMMANDE SET StatutCommande = ? WHERE COMMANDE.NumCommande = "+cetteNumeroCommande;
								PreparedStatement preparepst = connection.prepareStatement(query);
								preparepst.setString(1, "Prête pour livraison");
								// execute mise a jour des données
								int execution = preparepst.executeUpdate();


								// on va rafraichir la page, pour ca je ferme le vue et rouvre une nouvelle
								JFrame fenetre = new JFrame();
								VuePizzaiolo vuePizzaiolo = new VuePizzaiolo(vueConnexion);
								fenetre.add(vuePizzaiolo);
								fenetre.pack();
								fenetre.setVisible(true);
								fermerFenetre();

								// si > 0 cela signifie qu'une lige à bien été changé donc il y a bien eu mise à jour
								if (execution > 0) {
									System.out.println("Données lise à jour pour la commande"+cetteNumeroCommande);
								}
								else {
									System.out.println("Mise a jour non effectuée");
								}
							}
							// si c'est pas cocher alors
							else {
								int choix = JOptionPane.showConfirmDialog(null, "Etes vous sur de valider la commande ?", "Confirmation", JOptionPane.YES_NO_OPTION);
								if (choix == JOptionPane.YES_OPTION) {
									// ce bout de code concerne le changement dans la base de données concernant le statut de commande
									String query = "UPDATE COMMANDE SET StatutCommande = ? WHERE COMMANDE.NumCommande = "+cetteNumeroCommande;
									PreparedStatement preparepst = connection.prepareStatement(query);
									preparepst.setString(1, "Prête pour livraison");
									// execute mise a jour des données
									int execution = preparepst.executeUpdate();


									// on va rafraichir la page, pour ca je ferme le vue et rouvre une nouvelle
									JFrame fenetre = new JFrame();
									VuePizzaiolo vuePizzaiolo = new VuePizzaiolo(vueConnexion);
									fenetre.add(vuePizzaiolo);
									fenetre.pack();
									fenetre.setVisible(true);
									fermerFenetre();

									// si > 0 cela signifie qu'une lige à bien été changé donc il y a bien eu mise à jour
									if (execution > 0) {
										System.out.println("Données lise à jour pour la commande"+cetteNumeroCommande);
									}
									else {
										System.out.println("Mise a jour non effectuée");
									}
								}
								else {
									
								}
							}


						}catch (SQLException ex) {
							ex.printStackTrace();
						}
						
					}

				});
				buttonPanel.add(btnValider);

				// Ajout du panel de boutons en bas de la vue
				pizzaPanel.add(buttonPanel, BorderLayout.SOUTH);

				// Ajout du panel de pizza au panel principal
				pnlCommandeEnPreparation.add(pizzaPanel);

			}
			
			// ajoute les deux panels à un panel plus large
			pnlPrincipal.add(pnlCommandeValidee);
			pnlPrincipal.add(pnlCommandeEnPreparation);

			// on ajoute le panel principal à la fenetre
			this.add(pnlPrincipal);


			
			
			// ------------------------ bouton deconnexion de la page ---------------------//
			
			// ajout du bouton deconnexion pour permettre au pizzaiolo de quitter son écran et de mettre fin à sa journée
			// ce bouton est un JButton car il y en qu'un seul
			btnDeconnexion = new JButton("Déconnexion");
			btnDeconnexion.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					System.out.println("bouton valider cliqué");
					try {
						// ce bout de code concerne le changement dans la base de données concernant le statut du pizzaiolo
						// en effet lorsque le pizzaiolo se decpnnecte sont statut change alors nous le faisons ici
						// statut recherché
						String statut = "'En cuisine';";
						String query = "UPDATE PIZZAIOLO SET DisponibilitePizzaiolo = ? WHERE PIZZAIOLO.DisponibilitePizzaiolo = "+statut;
						PreparedStatement preparepst = connection.prepareStatement(query);
						preparepst.setString(1, "Disponible");
						// execute mise a jour des données
						preparepst.executeUpdate();


						// on deconnecte le pizzaiolo en le faisant retourner vers la page de connexion
						JFrame fenetre = new JFrame();
						fenetre.add(vueConnexion);
						fenetre.pack();
						fenetre.setVisible(true);
						fermerFenetre();


					}catch (SQLException ex) {
						ex.printStackTrace();
					}
					// on ferme la connection à la base de données
					ConnexionBDD.closeConnection(connection);
				}
			});
			// on centre le bouton
			btnDeconnexion.setAlignmentX(Component.CENTER_ALIGNMENT);
			// création d'un espace pour que le bouton se place en dessous
			this.add(Box.createVerticalGlue());
			// on ajoute le bouton
			this.add(btnDeconnexion);

			
			
			
			
			
			// ------------------------ bouton rafraichir la page ---------------------//
			
			btnRafraichir = new JButton("Rafraichir la page");
			btnRafraichir.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					JFrame fenetre = new JFrame();
					VuePizzaiolo vuePizzaiolo = new VuePizzaiolo(vueConnexion);
					fenetre.add(vuePizzaiolo);
					fenetre.pack();
					fenetre.setVisible(true);
					fermerFenetre();
				}

			});
			// on centre le bouton
			btnRafraichir.setAlignmentX(Component.CENTER_ALIGNMENT);
			// création d'un espace pour que le bouton se place en dessous
			this.add(Box.createVerticalGlue());
			this.add(btnRafraichir);



		}catch (SQLException ex) {
			ex.printStackTrace();
		}
		

	}


	//**************************************************************************//
	//********************************** METHODE  ******************************//
	//**************************************************************************//	

	// ajout d'écouteur mais qui ne fonctionne pas avec le controller, je les laisse pour montrer le fait d'avoir essayé
	public void btnDeconnexionClick(ActionListener ecouteur) {
		btnDeconnexion.addActionListener(ecouteur);
	}
	


	public void fermerFenetre() {
		Window parentWindow = SwingUtilities.windowForComponent(VuePizzaiolo.this);
		if (parentWindow != null) {
			parentWindow.dispose(); // Ferme la fenêtre parente
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	//**************************************************************************//
	//************************ ACCESSEUR / SETTER ******************************//
	//**************************************************************************//
	public boolean isCoche() {
		return coche;
	}


	public void setCoche(boolean coche) {
		this.coche = coche;
	}
	public JButton getBtnDeconnexion() {
		return btnDeconnexion;
	}


	public void setBtnDeconnexion(JButton btnDeconnexion) {
		this.btnDeconnexion = btnDeconnexion;
	}

}

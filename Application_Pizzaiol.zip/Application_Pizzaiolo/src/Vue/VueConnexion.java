/**
 * @author BLANCHET Erwan TP3B1
 *
 */

package Vue;

import javax.swing.*;

import com.mysql.cj.*;
import com.mysql.cj.xdevapi.Statement;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.io.*;

import Controller.*;

public class VueConnexion extends JPanel {

	//****************************************************************//
	//*************************** ATTRIBUTS***************************//
	//****************************************************************//
	// declaration des label
	private JLabel lblTitre;
	private JLabel lblEmail;
	private JLabel lblMdp;
	
	// declaration des zones de texte
	private JTextField txtEmail;
	private JTextField txtMotDePasse;
	
	// déclaration des boutons
	private JButton btnConnecter;
	private JButton btnRetour;
	private JButton btnPasDeCompte;
	
	// declaration des vues
	VueConnexion vueConnexion;
	//VuePizzaiolo vuePizzaiolo;
	VueCreationCompte vueCreaCompte;
	
	// declaration d'un controlleur
	ControllerConnexion controllerConnexion;

	
	
	
	//****************************************************************//
	//*************************** CONSTRUCTEUR ***********************//
	//****************************************************************//
	public VueConnexion() {
		setLayout(new BorderLayout());

		// Panel central avec GridLayout
		JPanel panel = new JPanel();
		panel.setLayout(new GridLayout(6, 2, 10, 10)); // Ajout d'un espacement entre les composants

		// Ajout du titre au milieu
		lblTitre = new JLabel("Page de Connexion des pizzaiolos", SwingConstants.CENTER);
		lblTitre.setFont(new Font("Arial", Font.BOLD, 18));

		// attribution du texte par defaut indiquant ce que l'on veut à l'utilisateur
		lblEmail = new JLabel("Entrez votre email");
		lblMdp = new JLabel("Entrez votre mot de passe");
		txtEmail = new JTextField();
		txtMotDePasse = new JTextField();
		btnConnecter = new JButton("Se connecter");
		btnRetour = new JButton("Retour");
		btnPasDeCompte = new JButton("Nouveau compte");

		panel.add(lblTitre);
		panel.add(new JLabel()); // Espace vide
		panel.add(lblEmail);
		panel.add(txtEmail);
		panel.add(lblMdp);
		panel.add(txtMotDePasse);
		panel.add(btnRetour);
		panel.add(btnConnecter);
		panel.add(btnPasDeCompte);

		// Panel avec BoxLayout pour l'espacement
		JPanel spacingPanel = new JPanel();
		spacingPanel.setLayout(new BoxLayout(spacingPanel, BoxLayout.Y_AXIS));
		spacingPanel.add(Box.createVerticalGlue());

		// Ajout des panels au panel principal
		add(spacingPanel, BorderLayout.WEST);
		add(panel, BorderLayout.CENTER);



		// -------------------------------------------------------------------------------------- //
		// affichage du logo de la pizzeria
		ImageIcon logo = new ImageIcon("logo.png");
		Image image = logo.getImage();
		Image nouvelleImage = image.getScaledInstance(150, 150, java.awt.Image.SCALE_SMOOTH);
		ImageIcon logoRetravaille = new ImageIcon(nouvelleImage);
		JLabel lbl = new JLabel(logoRetravaille);
		this.add(lbl, BorderLayout.SOUTH);
		// -------------------------------------------------------------------------------------- //

		// Style pour rendre l'interface plus attrayante
		lblEmail.setFont(new Font("Arial", Font.BOLD, 14));
		lblMdp.setFont(new Font("Arial", Font.BOLD, 14));
		btnConnecter.setBackground(new Color(0, 150, 136)); // Couleur de fond
		btnConnecter.setForeground(Color.WHITE); // Couleur du texte
		btnRetour.setForeground(new Color(0, 150, 136)); // Couleur du texte
		btnRetour.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10)); // Ajustement des marges
		

	}
	
	
	
	
	//****************************************************************//
	//*************************** METHODES  **************************//
	//****************************************************************//
	/**
	 * Ajoute un ecouteur au bouton retour qui serra gérer dans le controller
	 * @param ecouteur
	 */
	public void btnRetourClick(ActionListener ecouteur) {
		btnRetour.addActionListener(ecouteur);
	}
	
	/**
	 * Ajoute un ecouteur au boouton se connecter qui serra gérer dans le controller
	 * @param ecouteur
	 */
	public void btnConnecterClick(ActionListener ecouteur) {
		btnConnecter.addActionListener(ecouteur);
	}
	
	/**
	 * Ajoute un ecouteur au bouton que l'utilisateur n'a pas de compte qui serra gérer dans le controller
	 * @param ecouteur
	 */
	public void btnPasDeCompte(ActionListener ecouteur) {
		btnPasDeCompte.addActionListener(ecouteur);
	}

	/**
	 * Ferme la fenetre pour éviter d'avoir trop de fenetre en meme temps
	 */
	public void fermerFenetre() {
		Window parentWindow = SwingUtilities.windowForComponent(VueConnexion.this);
		if (parentWindow != null) {
			parentWindow.dispose(); // Ferme la fenêtre parente
		}
	}
	
	
	

	
	public JButton getBtnPasDeCompte() {
		return btnPasDeCompte;
	}
	public void setBtnPasDeCompte(JButton btnPasDeCompte) {
		this.btnPasDeCompte = btnPasDeCompte;
	}
	public JLabel getLblTitre() {
		return lblTitre;
	}

	public void setLblTitre(JLabel lblTitre) {
		this.lblTitre = lblTitre;
	}

	public JLabel getLblEmail() {
		return lblEmail;
	}

	public void setLblEmail(JLabel lblEmail) {
		this.lblEmail = lblEmail;
	}

	public JLabel getLblMdp() {
		return lblMdp;
	}

	public void setLblMdp(JLabel lblMdp) {
		this.lblMdp = lblMdp;
	}

	public JTextField getTxtEmail() {
		return txtEmail;
	}

	public void setTxtEmail(JTextField txtEmail) {
		this.txtEmail = txtEmail;
	}

	public JTextField getTxtMotDePasse() {
		return txtMotDePasse;
	}

	public void setTxtMotDePasse(JTextField txtMotDePasse) {
		this.txtMotDePasse = txtMotDePasse;
	}

	public JButton getBtnConnecter() {
		return btnConnecter;
	}

	public void setBtnConnecter(JButton btnConnecter) {
		this.btnConnecter = btnConnecter;
	}

	public JButton getBtnRetour() {
		return btnRetour;
	}

	public void setBtnRetour(JButton btnRetour) {
		this.btnRetour = btnRetour;
	}

	public VueConnexion getVueConnexion() {
		return vueConnexion;
	}

	public void setVueConnexion(VueConnexion vueConnexion) {
		this.vueConnexion = vueConnexion;
	}

}